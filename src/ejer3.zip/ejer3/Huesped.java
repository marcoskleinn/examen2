package ejer3;

import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

public class Huesped {
	
	private String nombre;
	private String apellido;
	private String dni;
	private Habitacion habitacion;
	public Huesped(String nombre, String apellido, String dni, Habitacion habitacion) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.habitacion = habitacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	
	
	public Habitacion getHabitacionn() {
		return habitacion;
	}
	public void setHabitacionn(Habitacion habitacion) {
		this.habitacion = habitacion;
	}
	public ArrayList<Integer> reservarHabitacion() {
		
		
	

		this.setNombre(JOptionPane.showInputDialog("Ingrese su nombre"));
		this.setApellido(JOptionPane.showInputDialog("Ingrese su apellido"));
		this.setDni(JOptionPane.showInputDialog("Ingrese su dni"));

			JOptionPane.showMessageDialog(null, "Tenemos habitacion: Habitacion Presidencial \n"
					+ "Habitacion Deluxe \n"
					+ "Habitacion Economica");
			
			/*int numero = (int) (Math.random()* 500);
			this.habitacion.getHabitaciones().add(numero);
			*/
			
		String opcion = JOptionPane.showInputDialog("Escriba el tipo de habitacion que quiere (presidencial, deluxe o economica)");
		
		while (opcion.equalsIgnoreCase("presidencial") || opcion.equalsIgnoreCase("deluxe") || opcion.equalsIgnoreCase("economica")) {
			
			int dias = Integer.parseInt(JOptionPane.showInputDialog("Ingrese noches que va a estar"));
			
			if (dias > 0) {
				int precio = (int)(Math.random() * 10000000);
				this.habitacion.getHotel().setPrecioXNoche(precio);
				
				int total = this.habitacion.getHotel().getPrecioXNoche() * dias;
				
				JOptionPane.showMessageDialog(null, "Seria un total de  " + total);
				
				String desea = JOptionPane.showInputDialog("Desea reservar?");
				if (desea.equalsIgnoreCase("si")) {
					int numeroHabitacion = (int) (Math.random()* 500);
					this.habitacion.getHabitaciones().add(numeroHabitacion);
					JOptionPane.showMessageDialog(null, "Habitacion reservada");
				}
			} else {
				JOptionPane.showMessageDialog(null, "Error");
			}
			
			
		}
		
		
			
			
			
			
			
		
		return this.habitacion.getHabitaciones();
			
			
		
		
	}
}
